package com.niit.collaborationxml.dao;

import java.util.List;

import com.niit.collaborationxml.model.UserDetails;

public interface UserDetailsDAO {
        
//	public List<UserDetails> list();
	
	public void saveOrUpdate(UserDetails userdetails);
	
//	public UserDetails getUserByName(String username);
	
//	public UserDetails getUserById(int userid);
	
}
