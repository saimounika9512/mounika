package com.niit.collaborationxml.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.collaborationxml.model.UserDetails;

public class UserDetailsDAOImpl  implements UserDetailsDAO  {
      public UserDetailsDAOImpl() {
      
      }
      
      @Autowired
      private SessionFactory sessionFactory;
      
		public void setSessionfactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}



	public void saveOrUpdate(UserDetails userdetails) {
		Session s =sessionFactory.getCurrentSession();
		Transaction t = s.beginTransaction();
		s.saveOrUpdate(userdetails);
		t.commit();
		
	}
	
	
/*	public List<UserDetails> list() {
		@SuppressWarnings("unchecked")
		Session session=this.sessionFactory.getCurrentSession();
		 @SuppressWarnings("unchecked")
		List<UserDetails> user = (List<UserDetails>) sessionFactory.getCurrentSession().
		createCriteria(UserDetails.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		 return user;	
		 }
	
	@Override
	public UserDetails getUserByName(String username) {
		System.out.println("getting data in dao based on name"+username);
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		Criteria cr=session.createCriteria(UserDetails.class);
		cr.add(Restrictions.eq("username", username));
		List<UserDetails> users = cr.list();
		UserDetails user = users.get(0);
		System.out.println("User Data="+user.getName());
		tx.commit();
		return user;
	}

	
	public UserDetails getUserById(int userid) {
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		UserDetails u=(UserDetails) session.load(UserDetails.class,userid);
		System.out.println("data of user by id="+u);
		tx.commit();
		return u;
	}*/

}
