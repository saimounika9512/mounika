package com.niit.collaborationxml.services;

import java.util.List;

import com.niit.collaborationxml.model.UserDetails;

public interface UserService {
 
//	 public List<UserDetails>list();
	 
	 public void saveOrUpdate(UserDetails userdetails);
	 
//	 public UserDetails getUserByname(String name);
	 
//	 public UserDetails getUserBYId(int id);
}
