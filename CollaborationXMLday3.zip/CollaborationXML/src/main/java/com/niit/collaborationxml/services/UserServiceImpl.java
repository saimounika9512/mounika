package com.niit.collaborationxml.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaborationxml.dao.UserDetailsDAO;
import com.niit.collaborationxml.model.UserDetails;

public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDetailsDAO userdao;
	
	
	/*@Transactional
	public List<UserDetails> list() {
		
		return userdao.list();
	}*/

	@Transactional
	public void saveOrUpdate(UserDetails userdetails) {
		
		userdao.saveOrUpdate(userdetails);
		
	}

/*	@Transactional
	public UserDetails getUserByname(String name) {
		
		return userdao.getUserByName(name);
	}

	@Transactional
	public UserDetails getUserBYId(int id) {
		
		return userdao.getUserById(id);
	}
*/
}
