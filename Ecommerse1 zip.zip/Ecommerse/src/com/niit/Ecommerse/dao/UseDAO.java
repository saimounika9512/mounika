package com.niit.Ecommerse.dao;

public class UseDAO {
	public boolean isValidCredentials(String Userid,String Password)
    {
    	if(Userid.equals("mounika")&& Password.equals("12345"))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
}
}
