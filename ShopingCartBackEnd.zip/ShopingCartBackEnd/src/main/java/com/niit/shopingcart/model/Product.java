package com.niit.shopingcart.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "product")
@Component
public class Product {

	@Id
	private String  id;
	private String name;
	
	private String description;
	private double price;
	
	/*@Column(name = "category_id")
	private String category_ID;
	
	@Column(name = "supplier_id")
	private String supplier_ID;*/
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	/*public String getCategory_ID() {
		return category_ID;
	}
	public void setCategory_ID(String category_ID) {
		this.category_ID = category_ID;
	}
	
	public String getSupplier_ID() {
		return supplier_ID;
	}
	public void setSupplier_ID(String supplier_ID) {
		this.supplier_ID = supplier_ID;
	}
	@Override
	public String toString()
	{
		return "[Product INformation Pid="+ id + "product name="+name+"description ="+description+"price ="+price+"category="+category_ID+"]";
	}*/
	
	

}
