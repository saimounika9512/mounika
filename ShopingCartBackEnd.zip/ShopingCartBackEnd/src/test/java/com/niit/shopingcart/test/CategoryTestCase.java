package com.niit.shopingcart.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.CategoryDAO;


public class CategoryTestCase {
	AnnotationConfigApplicationContext context;
	CategoryDAO categoryDAO;
	@Before
		public void init() {
		  context=new AnnotationConfigApplicationContext();
		  context.scan("com.niit.shopingcart");
		  context.refresh();
			
			categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
			
		}
	@Test
	public void listAllCatagioresTestCase()
	{
		assertEquals("list usres",4,categoryDAO.list().size());
	}
		
	}
