package com.niit.shopingcart.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.UserDAO;

public class UserTestCase {
AnnotationConfigApplicationContext context;
 UserDAO userDAO;
	@Before
	public void init() {

		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
		userDAO=(UserDAO) context.getBean("userDAO");
	}
@Test
public void isValidUsertestCase()
{
	assertEquals("valid user test case",true,userDAO.isValidUser("admin", "admin", true));
}
	
@Test
public void listAllUsersTestCase()
{
	assertEquals("list usres",3,userDAO.list().size());
}
	
	
	
}
