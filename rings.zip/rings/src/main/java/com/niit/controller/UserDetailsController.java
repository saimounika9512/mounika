package com.niit.controller;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.UserDetailsDAO;
import com.niit.model.UserDetails;




@Controller
public class UserDetailsController {
	
	Logger log = LoggerFactory.getLogger("UserDetailsController");

   @Autowired
	UserDetailsDAO userDetailsDAO;
    
	@RequestMapping(value= "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute UserDetails userDetails) {
		log.debug("starting of method registerUser");
		System.out.println("************register called in UserDetailsController**********");
		userDetails.setEnabled(true);
		userDetails.setUser_role_id(2);
		userDetailsDAO.saveOrUpdate(userDetails);
	   return new ModelAndView("redirect:/userHome");
	 }
	
	@RequestMapping(value = "/admin**", method = RequestMethod.GET)
	public ModelAndView adminPage()
	{
        System.out.println("**********adminPage called in UserDetailsController************");
		return new ModelAndView("adminHome");
	}
	
	@RequestMapping(value = "/userHome**", method = RequestMethod.GET)
	public ModelAndView userPage() 
	{
		System.out.println("**********userPage called in UserDetailsController***********");
		return new ModelAndView("indexuser");
	}
	
	@RequestMapping("/viewUser")
	public ModelAndView showCustomers()
	{
		List<UserDetails> user=userDetailsDAO.viewUserDetails();
		String jsonData="";
		ObjectMapper mapper=new ObjectMapper();
		try {
			jsonData=mapper.writeValueAsString(user);
			System.out.println(jsonData);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("viewUser", "listofusers", jsonData);
	}

}
