package com.niit.dao;

import com.niit.model.BillingAddress;

public interface BillingAddressDAO {
	
	//public List<BillingAddress> list();

	//public BillingAddress get(String id);

	public void saveOrUpdate(BillingAddress billingAddress);
	
	//public void delete(int id);
}
