package com.niit.dao;

import com.niit.model.Payment;

public interface PaymentDAO {
	
	public void saveOrUpdate(Payment payment);

}
