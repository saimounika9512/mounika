package com.niit.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Payment;



@Repository("paymentDAO")
public class PaymentDAOImpl implements PaymentDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public PaymentDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveOrUpdate(Payment payment)
	{
		System.out.println("***********saveOrUpdate called in PaymentDAOImpl*********");
		
		sessionFactory.getCurrentSession().saveOrUpdate(payment);
	
	}

}
