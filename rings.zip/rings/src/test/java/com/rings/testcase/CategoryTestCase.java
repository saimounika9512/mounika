package com.rings.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDAO;

public class CategoryTestCase {

	AnnotationConfigApplicationContext context;
	CategoryDAO categoryDAO;
	
	@Before
	public void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
		
	}
	
	@Test
	public void listAllUsersTestCase()
	{
		assertEquals("list users",3,categoryDAO.list().size());
	}	

}
