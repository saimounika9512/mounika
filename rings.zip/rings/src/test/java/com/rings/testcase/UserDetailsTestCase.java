package com.rings.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDetailsDAO;

public class UserDetailsTestCase {

	AnnotationConfigApplicationContext context;
	UserDetailsDAO userDetailsDAO;
	
	@Before
	public void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		userDetailsDAO=(UserDetailsDAO)context.getBean("userDetailsDAO");
		
	}
	
	@Test
	public void listAllUsersTestCase()
	{
		assertEquals("list users",3,userDetailsDAO.list().size());
	}	

}
